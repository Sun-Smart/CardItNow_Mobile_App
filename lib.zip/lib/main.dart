import 'package:cardit/route_generator.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:hexcolor/hexcolor.dart';
import 'dart:async';

import 'services/appglobal.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
          brightness: AppGlobal().brightness,
          fontFamily: 'Sora',
          primaryColor: Colors.white,
          scaffoldBackgroundColor: Color(0xFFffffff),
          appBarTheme: const AppBarTheme(
            elevation: 0,
            color: Color(0xFFffffff),
          )),
      initialRoute: "/",
      onGenerateRoute: RouteGenerator.generateRoute,
    );
  }
}
