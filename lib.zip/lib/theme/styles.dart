import 'package:flutter/cupertino.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter/material.dart';

import '../services/appglobal.dart';

abstract class Styles {
  static Color get colorSectionTitle =>
      AppGlobal().isDark ? Color(0xff333333) : Color(0xffe5e5e5);

  static Color get colorItemBackground =>
      AppGlobal().isDark ? Color(0xff000000) : Color(0xffffffff);

  static Color get colorItemDetailBackground =>
      AppGlobal().isDark ? Color(0xff1f1f1f) : Color(0xffefefef);

  static Color get colorListDivider =>
      AppGlobal().isDark ? Color(0xff333333) : Color(0xffe5e5e5);

  static Color get colorUnitText =>
      AppGlobal().isDark ? Color(0xffffffff) : Color(0xff000000);
}
